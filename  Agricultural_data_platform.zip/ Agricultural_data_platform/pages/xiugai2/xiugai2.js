// pages/xiugai2/xiugai2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    newpassword: "",
    towpassword: "",
    id:""
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
this.setData({
  id:options.id
})
  },
  adjust: function(res) {
    var that=this
    const db = wx.cloud.database();
    const admin = db.collection('Users');
    if(that.data.newpassword==that.data.towpassword){
    admin.doc(that.data.id).update({
      data: {
        password: that.data.newpassword,
      }
    }).then(res => {
      wx.showToast({
        title: '密码修改成功',
        icon:'none',
        duration:1500
      })
      setTimeout(function () {
        wx.reLaunch({
          url: '../../pages/login/user',
        })       
      }, 2000);
    })
    }else{
      wx.showToast({
        title: '两次输入不同',
        icon: 'none',
        duration: 2500,
      })
    }
  },
  getnewpassword: function(res) {
    this.setData({
      newpassword: res.detail.value
    })
  },
  gettowpassword: function (res) {
    this.setData({
      towpassword: res.detail.value
    })
  }
})