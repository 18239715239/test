// pages/user/user.js
let app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "",
    phone: "",
    password: "",
    code: "",
    inputcode: "",
    choosed: '1'
  },
  radioChange(e) {
    var that = this
    console.log(e)
    that.setData({
      choosed: e.detail.value
    })
  },
  bindName(e) {

    this.setData({
      name: e.detail.value
    })
  },
  bindyanzheng(e) {
    this.setData({
      inputcode: e.detail.value
    })
  },
  bindPhone(e) {
    this.setData({
      phone: e.detail.value
    })
  },
  bindPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },
  denglu: function(e) {
    var that = this;
    if (that.data.choosed == 1) {//选择了普通用户登录
      wx.showToast({
        title: '登录验证中',
        icon: 'loading',
        duration: 5000,
      })
      var is = false; //判断输入信息是否与数据库匹配到
      const db = wx.cloud.database();
      const admin = db.collection('Users');
      admin.get({
        success: function(res) {
          console.log(res)
          for (var i = 0; i < res.data.length; ++i) {
            if (res.data[i].phone == that.data.phone && res.data[i].password == that.data.password && res.data[i].name == that.data.name && that.data.inputcode == that.data.code) {
              app.globalData.nowname = that.data.name;
              app.globalData.nowpassword = that.data.password;
              app.globalData.nowphone = that.data.phone;
              is = true;
              wx.switchTab({
                url: '../../pages/index/index',
                fail: function() {
                  wx.showToast({
                    title: '服务器异常',
                    duration: 1500
                  })
                }
              })
            }
          }
          if (is == false) {
            console.log(i)
            wx.showToast({
              title: '输入信息有误',
              icon: 'none',
              duration: 2500,
            })
          }
        }
      })
    }
    if (that.data.choosed == 2) {//选择了管理员登录
      wx.showLoading({
        title: '登录验证中',
        icon: 'loading',
        duration: 5000,
      })
      if ('18239715239' == that.data.phone && '123456' == that.data.password && '管理员' == that.data.name && that.data.inputcode == that.data.code) {
        wx.reLaunch({
          url: '../../pages/master/master',
        })
        wx.hideLoading()
      }else{
          wx.showToast({
            title: '您不是管理员',
            icon:'none',
            duration: 2000
          })
      }
    }
  },

  wangji: function() {
    var that = this;
    var is = false
    const db = wx.cloud.database();
    const admin = db.collection('Users');
    admin.get({
      success: function(res) {
        console.log(that.data)
        for (var i = 0; i < res.data.length; i++) {
          if (res.data[i].phone == that.data.phone && res.data[i].name == that.data.name && that.data.inputcode == that.data.code) {
            wx.reLaunch({
              url: '/pages/forget/forget?id=' + res.data[i]._id,
            })
            is = true
          }
        }
        if (is == false) {
          wx.showToast({
            title: '信息填写错误',
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
  },
  huanyizhang: function() {
    this.createCode()
  },
  createCode: function() {
    var code = '';
    //设置长度，这里看需求，我这里设置了4
    var codeLength = 4;
    //设置随机字符
    var randoms = [2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    //循环codeLength 我设置的4就是循环4次
    for (var i = 0; i < 4; i++) {
      //设置随机数范围,这设置为0 ~ 32，去掉了01和io
      var index = Math.floor(Math.random() * randoms.length);
      code += randoms[index];
    }
    //将拼接好的字符串赋值给展示的code
    this.setData({
      code: code
    })
  },
  onShow: function() {
    this.createCode()
  }
})