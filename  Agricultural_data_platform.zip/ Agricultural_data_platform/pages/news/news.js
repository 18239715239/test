// pages/news/news.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    reach: 0,
    list:[],
    contentNewsList: [],
    id:'',
    tabs:[
      {
        id:0,
        name:"头条资讯",
        choosed:true
      },
       {
        id: 1,
        name: "农业资讯",
        choosed: false
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var reach = that.data.reach
    wx.request({
      url: 'https://way.jd.com/jisuapi/get?channel=头条&num=8&start=' + reach + '&appkey=1948902442a3e9836c9ef9d5b4b359b0',
      success: res => {
        console.log(res)

        that.setData({
          contentNewsList: res.data.result.result.list,
          reach:reach+41
        })
      }
    })
  },
  viewDetail: function(e) {
    var that = this;
    var urls = e.currentTarget.dataset.url
    var content = e.currentTarget.dataset.content
    var id = e.currentTarget.dataset.id
    console.log(urls)
    wx.navigateTo({
      url: '/pages/newsview/newsview?url=' + urls + '&content=' + content + '&id=' + id,
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    var that = this;
    if(that.data.id==0){
    wx.showLoading({
      title: '加载更多',
      duration:5000
    });
    var reach = that.data.reach//起始页码
    wx.request({
      url: 'https://way.jd.com/jisuapi/get?channel=头条&num=80&start=' + reach + '&appkey=1948902442a3e9836c9ef9d5b4b359b0',
      success: res => {
        console.log(res)
        if (reach > 40) {
          var contentNewsListtemp = that.data.contentNewsList
          that.setData({
            contentNewsList: contentNewsListtemp.concat(res.data.result.result.list),
            reach: reach + 40
          })
        } else {
          that.setData({
            contentNewsList: res.data.result.result.list,
            reach: reach + 40
          })
        }
      },
      fail(){
        wx.showToast({
          title: '服务器异常',
          icon:'none',
          duration:2500
        })
      },
      complete:function(){
        wx.hideLoading()
      }
    })
    }
    if(that.data.id===1){
      wx.showToast({
        title: '没有更多数据了',
        icon:'none',
        duration:2000
      })
    }
  },
  show(e){
    var that = this
    var tabs = that.data.tabs
    //遍历数组，某项被选中后choosed赋值为true，其他项为false
    tabs.forEach((v, i) => i === e.currentTarget.dataset.id ? v.choosed = true : v.choosed = false)
    that.setData({
      tabs,
      id: e.currentTarget.dataset.id
    })
    if (e.currentTarget.dataset.id===0){
      var reach = that.data.reach
      wx.request({
        url: 'https://way.jd.com/jisuapi/get?channel=头条&num=20&start=' + reach + '&appkey=1948902442a3e9836c9ef9d5b4b359b0',
        success: res => {
          console.log(res)

          that.setData({
            contentNewsList: res.data.result.result.list,
            reach: reach + 41
          })
        }
      })
    }
    if (e.currentTarget.dataset.id === 1){
      const db = wx.cloud.database();
      db.collection('news').get({
        success(res) {
          that.setData({
            contentNewsList: res.data
          })
          console.log(that.data.contentNewsList)
        }
      })
    }
  }
})