// pages/register/register.js
let app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "",
    phone: "",
    password: "",
    code: "",
    inputcode: "",
  },
  bindName(e) {
    this.setData({
      name: e.detail.value
    })

  },
  bindyanzheng(e) {
    this.setData({
      inputcode: e.detail.value
    })
  },
  bindPhone(e) {
    this.setData({
      phone: e.detail.value
    })
  },
  bindPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  huanyizhang: function() {
    this.createCode()
  },
  createCode: function() {
    var code = '';
    //设置长度，这里看需求，我这里设置了4
    var codeLength = 4;
    //设置随机字符
    var randoms = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    //循环codeLength 我设置的4就是循环4次
    for (var i = 0; i < 4; i++) {
      var index = Math.floor(Math.random() * randoms.length);
      code += randoms[index];
    }
    //将拼接好的字符串赋值给展示的code
    this.setData({
      code: code
    })
  },
  onShow: function() {
    this.createCode()
  },
  register: function(e) {
    var that = this;
    var isregi = false;
    var namerg = /^[0-9a-zA-Z\u4e00-\u9fa5_]{3,10}$/
    var passwordrg = /^(\w){6,20}$/
    var phonerg = /^1[3456789]\d{9}$/
    if (namerg.test(that.data.name)) {
      if (phonerg.test(that.data.phone)) {
        if (passwordrg.test(that.data.password)) {
          if (that.data.inputcode === that.data.code) {
            const db = wx.cloud.database();
            const admin = db.collection('Users');
            admin.get({
              success: function(res) {
                console.log(that.data.phone)
                for (var i = 0; i < res.data.length; i++) {
                  if (res.data[i].phone == that.data.phone) {
                    isregi = true;
                    wx.showToast({
                      title: '该手机号已注册',
                      icon: 'none',
                      duration: 2500,
                    })
                  }
                }
                ///
                if (isregi == false) {
                  admin.add({
                    data: {
                      name: that.data.name,
                      phone: that.data.phone,
                      password: that.data.password
                    },
                    success: function (res) {
                      wx.showToast({
                        title: '注册成功跳转中',
                        icon: 'loading',
                        duration: 2000,
                      });
                      app.globalData.nowname = that.data.name;
                      app.globalData.nowpassword = that.data.password;
                      app.globalData.nowphone = that.data.phone;
                      setTimeout(function () {
                        wx.switchTab({
                          url: '../../pages/index/index'
                        })
                      }, 3000)
                    },
                    fail: function () {
                      wx.showToast({
                        title: '注册失败',
                        icon: 'none',
                        duration: 3000,
                      })
                    }
                  })
                }
              },
              fail: function () {
                wx.showToast({
                  title: '网络异常',
                  icon: 'none',
                  duration: 3000,
                })
              }
            })
          } else {
            wx.showToast({
              title: '验证码输入错误',
              icon: 'none',
              duration: 3000,
            })
          }
        } else {
          wx.showToast({
            title: '密码格式错误',
            icon: 'none',
            duration: 3000,
          })
        }
      } else {
        wx.showToast({
          title: '手机号格式错误',
          icon: 'none',
          duration: 3000,
        })
      }
    } else {
      wx.showToast({
        title: '用户名格式错误',
        icon: 'none',
        duration: 3000,
      })
    }
  },
  onLoad: function(options) {
    wx.setNavigationBarTitle({
      title: '用户注册'
    })
  }
})