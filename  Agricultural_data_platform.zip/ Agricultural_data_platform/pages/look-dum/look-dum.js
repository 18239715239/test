// pages/data/data.js
import wxCharts from '../../utils/wxcharts.js'
var windowW
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageWidth: "",
    currentdata: "", //当前数据
    todaydata: [], //今日所有数据
    todaydata_item: [], //今日单项数据
    warn: '',
    currentdate: '',
    currenttime: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var date = new Date();
    var year = date.getUTCFullYear()
    var h = date.getHours();
    var month = date.getUTCMonth() + 1;
    var day = date.getUTCDate();
    var minute = date.getMinutes
    var second = date.getSeconds
    if (h < 10) {
      h = '0' + h
    }
    if (month < 10) {
      month = '0' + month
    }
    if (day < 10) {
      day = '0' + day
    }
    if (minute >= 30) {
      minute = 30
    } else {
      minute = '00'
    }
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    });
    //判断用户是否登录
    if (app.globalData.nowphone == '未登录') {
      wx.showToast({
        title: '请登录查看数据',
        icon: 'none',
        duration: 1800
      })
    } else {
      if (app.globalData.nowphone == '18239715239') {
        wx.request({
          url: 'http://116.62.36.8:9000/getData4',
          success: function(res) {
            console.log(res)
            wx.showLoading({
              title: '数据加载中',
              duration: 2000
            })
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].date == year + '.' + month + '.' + day) {
                that.setData({
                  todaydata: that.data.todaydata.concat(res.data.data[i])
                })
              }
            }

            if (that.data.todaydata != '') {
              for (var i = 0; i < 24; i++) {
                if (that.data.todaydata[i * 2].info.hum == '-') {
                  that.data.todaydata[i * 2].info.hum = " "
                }
                that.setData({
                  todaydata_item: that.data.todaydata_item.concat(that.data.todaydata[i * 2].info.hum)
                })
              }
              console.log(that.data.todaydata[0])
              // 排序，防止数据混乱
              // for (var i = 0; i < 12; i++) {
              //   for (var j = 0; j < that.data.todaydata_item.length ; j++) {
              //     if (that.data.todaydata[j].time ==(2*i)) {
              //       that.data.truedata[i]=that.data.todaydata_item[j]
              //       break
              //     }else{
              //       that.data.truedata[i]=''
              //     }
              //   }
              // }
              new wxCharts({
                canvasId: 'lineCanvas',
                type: 'line',
                categories: ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h', '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h', '23h'],
                animation: true,
                background: '#f5f5f5',
                series: [{
                  name: '湿度值24小时含量变化图示',
                  data: that.data.todaydata_item,
                }],
                xAxis: {
                  disableGrid: true,
                },
                yAxis: {
                  title: '湿度值(%)',
                  format: function(val) {
                    return val.toFixed(2);
                  },
                  min: 0,
                },
                width: that.data.imageWidth,
                height: 250,
                dataLabel: true,
                dataPointShape: true,
                extra: {
                  lineStyle: 'curve'
                }
              })
            } else {
              wx.showToast({
                title: '暂无数据',
                icon: 'none',
                duration: 3000
              })
            }
          },
          fail(e) {
            wx.showToast({
              title: '服务器异常',
              icon: 'none',
              duration: 3000
            })
          },
          complete() {
            wx.hideLoading()
          }
        })
      } else {
        wx.showToast({
          title: '您未安装设备',
          icon: 'none',
          duration: 2000
        })
      }
    }
  },
  moredata: function() {
    wx.navigateTo({
      url: '/pages/dum-hostory/dum-hostory'
    })
  },
  onShow() {
    var that = this
      if (app.globalData.nowphone == '18239715239') {
        wx.request({
          url: 'http://116.62.36.8:9000/real',
          success(e) {
            that.setData({
              currentdata: e.data.data[0].info.hum,
              currentdate: e.data.data[0].date,
              currenttime: e.data.data[0].time
            })
            if (that.data.currentdata > 40) {
              that.setData({
                warn: '当前环境湿度值过高，请注意！'
              })
            } else if (that.data.currentdata < 15) {
              warn: '当前环境湿度值过低，请注意！'
            }
            else {
              warn: ''
            }
          },
          fail() {
            wx.showToast({
              title: '服务器异常',
              icon: 'none',
              duration: 2000
            })
          }
        })
      } 
  }
})