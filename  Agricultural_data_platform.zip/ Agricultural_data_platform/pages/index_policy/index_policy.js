// pages/index_policy/index_policy.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs: [

      {
        id: 0,
        name: '农业法',
        choosed: true
      },
      {
        id: 1,
        name: '种子法',
        choosed: false
      },
      {
        id: 2,
        name: '农药法',
        choosed: false
      },
      {
        id: 3,
        name: '惠农政策',
        choosed: false
      },
    ],
    list: []
  },
  show(e) {
    var that = this
    var tabs = that.data.tabs
    //遍历数组，某项被选中后choosed赋值为true，其他项为false
    tabs.forEach((v, i) => i === e.currentTarget.dataset.id ? v.choosed = true : v.choosed = false)
    that.setData({
      tabs
    })
    console.log(e)
    if (e.currentTarget.dataset.id == 0) {
      const db = wx.cloud.database();
      db.collection('nongyefa').get({
        success(res) {
          that.setData({
            list: res.data
          })
          console.log(that.data.list)
        }
      })
    }
    if (e.currentTarget.dataset.id == 1) {
      const db = wx.cloud.database();
      db.collection('zhongzifa').get({
        success(res) {
          that.setData({
            list: res.data
          })
        }
      })
    }
    if (e.currentTarget.dataset.id == 2) {
      const db = wx.cloud.database();
      db.collection('nongyaofa').get({
        success(res) {
          that.setData({
            list: res.data
          })
        }
      })
    }
    if (e.currentTarget.dataset.id == 3) {
      const db = wx.cloud.database();
      db.collection('huinong').get({
        success(res) {
          that.setData({
            list: res.data
          })
        }
      })
    }
  },

  loadmore: function(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/help-detail/help-detail?content=' + e.currentTarget.dataset.content,
      success: function(res) {
        wx.showLoading({
          title: '加载中',
          icon: 'none',
          duration: 1000
        })
      },
      fail: function(res) {
        wx.showToast({
          title: '服务器异常',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function(res) {
        wx.hideLoading()
      },
    })
  },
  onLoad() {
    var that = this
    const db = wx.cloud.database();
    db.collection('nongyefa').get({
      success(res) {
        that.setData({
          list: res.data
        })
        console.log(that.data.list)
      }
    })
  }

})