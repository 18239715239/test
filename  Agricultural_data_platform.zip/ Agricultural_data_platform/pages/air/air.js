// pages/air/air.js
var app = getApp()
var QQMapWX = require('../../lib/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    time: '',
    pm: '',
    aq: '',
    no2: '',
    desc: '',
    sugg: '',
    city: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    wx.getLocation({
      success: function (res) {
        console.log(res)
        qqmapsdk = new QQMapWX({
          key: 'E63BZ-LR6CW-RFPRQ-OPSHA-F6Z2V-T5BOV'
        });
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: res.latitude,
            longitude: res.longitude,
          },
          success: function (res2) { //成功后的回调
            console.log(res2);
            var city = res2.result.address_component.city
            that.setData({
              city
            })
            wx.request({
              url: 'https://api.jisuapi.com/aqi/query?appkey=993123f768ea1000&city=' + that.data.city,
              success: function (res3) {
                console.log(res3)
                var data = res3.data.result
                that.setData({
                  time: data.timepoint,
                  pm: data.pm2_5,
                  aq: data.quality,
                  no2: data.no2,
                  desc: data.aqiinfo.affect,
                  sugg: data.aqiinfo.measure,
                })
              },
              fail(e) {
                console.log(e)
                wx.showToast({
                  title: '请求失败',
                  icon: 'none',
                  duration: 2000
                })
              }
            })
          }
        })
      }
    })
    
  },


  onShow: function() {
    
  },
  
})