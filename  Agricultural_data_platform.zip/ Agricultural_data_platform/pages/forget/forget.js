// pages/forget/forget.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '',
    password:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      id: options.id
    })
  },
  getpass: function() {
    var that = this;
    const db = wx.cloud.database();
    const admin = db.collection('Users');
    admin.get({
      success: function(res) {
        console.log(that.data)
        for (var i = 0; i < res.data.length; i++) {
          if (res.data[i]._id == that.data.id){
            that.setData({
              password: res.data[i].password 
            })
          }
        }
      }
    })
  },
  newgister:function(){
    wx.reLaunch({
      url: '/pages/login/user',
    })
  }
  ,
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})