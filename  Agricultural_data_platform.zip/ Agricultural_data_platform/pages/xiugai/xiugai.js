// pages/xiugai/xiugai.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
phone:"",
password:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
adjust:function(){
  var that=this;
  var is=false
  const db = wx.cloud.database();
  const admin = db.collection('Users');
  admin.get({
    success: function (res) {
      for (var i = 0; i < res.data.length; ++i) {
        if (res.data[i].phone == that.data.phone && res.data[i].password == that.data.password) {
          wx.navigateTo({
            url: '/pages/xiugai2/xiugai2?id='+res.data[i]._id,
          })
          is=true
        }
      }
      if (is == false) {
        wx.showToast({
          title: '输入信息有误',
          icon: 'none',
          duration: 2500,
        })
      }
    }
  })
},
getphone:function(res){
this.setData({
  phone:res.detail.value
})
},
getpassword: function (res) {
  this.setData({
  password: res.detail.value
  })
  }
})