Page({

  /**
   * 页面的初始数据
   */
  data: {
    location_text: '武汉',
    temperature: '30°',
    now_weather: '晴',
    now_air: '优',
    today: '2019-09-12',
    today_wind: '晴转多云'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.getCityAndWeather()
  },
  // 获取位置及天气
  getCityAndWeather() {
    var that = this;
    wx.getLocation({
      success: function (res) {

        var locationString = res.latitude + "," + res.longitude;
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/',
          data: {
            "key": "E63BZ-LR6CW-RFPRQ-OPSHA-F6Z2V-T5BOV",
            "location": locationString
          },
          method: 'GET',
          success: res2 => {

            console.log(res2)
            let city = res2.data.result.address_component.city
            that.setData({
              location_text: city,
            })
            console.log(that.data.location_text)
            that.getNowWeather();
          }
        })
      },
      fail: () => {
        console.log('未授权位置');
      }
    })
  },

  // 获取当前天气
  getNowWeather() {
    let that = this
    var location_text
    that.setData({
      location_text: that.data.location_text
    })


    let hfkey = 'd7c6d287483d419aae625d020b4cc03a'
    let url = 'https://free-api.heweather.net/s6/weather/now?key=' + hfkey + '&location=' + that.data.location_text
    wx.request({
      url: url,
      success: function (res) {
        console.log('success')
        console.log(res)
        let nowData = res.data.HeWeather6[0].now;
        //温度数据
        let temperature = nowData.tmp
        // 今日日期
        var date = new Date()
        //今天风向
        let wind_dir=nowData.wind_dir
        //今天风力
        var wind_str=nowData.wind_sc
        const year = date.getFullYear()
        const month = date.getMonth() + 1
        const day = date.getDate()
        that.setData({
          temperature: temperature + '℃',
          today: year + '-' + month + '-' + day,
          today_wind:wind_dir+wind_str+'级',
          now_weather: nowData.cond_txt
        })
      },
      fail: function (res) {
        console.log()
      }
    })
  }
})