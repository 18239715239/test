// pages/master/master.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    const db = wx.cloud.database();
    db.collection('Users').get({
      success(res) {
        console.log(res)
        that.setData({
          list: res.data
        })
      },
      fail(res) {
        wx.showToast({
          title: '服务器异常',
          icon: 'none',
          duration: 2000
        })
      }
    })
  },
  change_pass(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/master-oper/master-oper?id=' + e.currentTarget.dataset.id + '&lab=' + e.currentTarget.dataset.lab,
    })
  },
  change_name(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/master-oper/master-oper?id=' + e.currentTarget.dataset.id + '&lab=' + e.currentTarget.dataset.lab,
    })
  },
  deleted(e) {
    wx.showModal({
      title: '提示',
      content: '确定删除账号？',
      success(res) {
        if (res.confirm) {
          const db = wx.cloud.database();
          db.collection('Users').doc(e.currentTarget.dataset.id).remove().then(res => {
            wx.showToast({
              title: '用户删除成功',
              icon: 'none',
              duration: 1500
            })
            setTimeout(function() {
              wx.reLaunch({
                url: '../../pages/master/master',
              })
            }, 1000);
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  leave(){
    wx.reLaunch({
      url:'/pages/login/user',
    })
  },

 
})