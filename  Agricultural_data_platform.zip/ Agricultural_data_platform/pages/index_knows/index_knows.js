// pages/index_knows/index_knows.js
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    list:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var temp=''
    var that=this
    const db = wx.cloud.database();
    db.collection('know-1').get({
      success:function(res1){
        db.collection('know-2').get({
          success: function (res2) {
            db.collection('know-3').get({
              success: function (res3) {
                that.setData({
                  list: res1.data.concat(res2.data).concat(res3.data),
                })
              }
            })
          },
        })
      },
    })
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
wx.showToast({
  title: '没有更多了',
  icon:'none',
  duration:1500
})
  },
  loadmore:function(e){
    console.log(e)
    wx.navigateTo({
      url: '/pages/know-detail/know-detail?content=' + e.currentTarget.dataset.content,
      success: function(res) {
        wx.showLoading({
          title: '加载中',
          icon: 'none',
          duration: 1000
        })
      },
      fail: function(res) {
        wx.showToast({
          title: '服务器异常',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function(res) {
        wx.hideLoading()
      },
    })
  }
})