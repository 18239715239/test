// pages/moredata/moredata.js
import wxCharts from '../../utils/wxcharts.js'
var windowW
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageWidth: "",
    todaydata: [],
    month: '',
    day: "",
    timeh: [],
    timel: [],
    todaydata_item: [],
    truedata: [],
    info: ''
  },
  month: function(res) {
    this.setData({
      month: res.detail.value
    })
  },
  day: function(res) {
    this.setData({
      day: res.detail.value
    })
  },
  lookmore: function() {
    var that = this
    that.setData({
      todaydata_item: [],
      todaydata: [],
    })
    var date = new Date()
    var year = date.getFullYear()
    var rgmonth = /^[0-9][0-9]?$/
    if (this.data.month < 1 || this.data.month > 12 || this.data.day < 0 || this.data.day > 31 || rgmonth.test(that.data.month) == false || rgmonth.test(that.data.day) == false || that.data.month.length != 2 || that.data.day.length != 2) {
      console.log(this.data.month)
      wx.showToast({
        title: '请输入正确的天数或月份',
        icon: 'none',
        duration: 3000,
      })
    } else {
      if (app.globalData.nowphone == '18239715239') {
        wx.request({
          url: 'http://116.62.36.8:9000/getData4',
          success: function(res) {
            wx.showLoading({
              title: '数据加载中',
              duration: 2000
            })
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].date == year + '.' + that.data.month + '.' + that.data.day) {
                that.setData({
                  todaydata: that.data.todaydata.concat(res.data.data[i])
                })
              }
            }
            if (that.data.todaydata!=''){
            for (var i = 0; i < 24; i++) {
              if (that.data.todaydata[i * 2].info.hum == '-') {
                that.data.todaydata[i * 2].info.hum = ""
              }
              that.setData({
                todaydata_item: that.data.todaydata_item.concat(that.data.todaydata[i * 2].info.hum)
              })
            }
            for (var i = 0; i < that.data.todaydata.length; i++) {
              if (that.data.todaydata[i].info.hum > 40) {
                that.setData({
                  timeh: that.data.timeh.concat(that.data.todaydata[i].time)
                })
              }
              if (that.data.todaydata[i].info.hum < 15) {
                that.setData({
                  timel: that.data.timel.concat(that.data.todaydata[i].time)
                })
              }
            }
            if (that.data.timeh.length != 0 || that.data.timel.length !=                0) {
              that.setData({
                info: ''
              })
            } else {
              that.setData({
                info: '该日土壤湿度值正常'
              })
            }
            new wxCharts({
              canvasId: 'lineCanvas',
              type: 'line',
              categories: ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h', '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h', '23h', ],
              animation: true,
              background: '#f5f5f5',
              series: [{
                name: '湿度值24小时含量变化图示',
                data: that.data.todaydata_item,
              }],
              xAxis: {
                disableGrid: true,
              },
              yAxis: {
                title: '湿度值%',
                format: function(val) {
                  return val.toFixed(2);
                },
                min: 0,
                max: 14,
              },
              width: that.data.imageWidth,
              height: 250,
              dataLabel: true,
              dataPointShape: true,
              extra: {
                lineStyle: 'curve'
              }
            })
          }else{
            wx.showToast({
              title: '暂无数据',
              icon: 'none',
              duration: 3000
            })
          }
          },
          fail(e) {
            wx.showToast({
              title: '服务器异常',
              icon: 'none',
              duration: 3000
            })
          },
          complete() {
            wx.hideLoading()
          }
        })
      } else {
        wx.showToast({
          title: '您未安装设备',
          icon: 'none',
          duration: 2000
        })
      }
    }
  },
  onLoad: function(options) {
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    })
  },

})