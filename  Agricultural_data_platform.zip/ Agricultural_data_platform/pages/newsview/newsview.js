// pages/newsview/newsview.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: '',
    newcontent:'跳转加载中...'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options)
    var that = this
    if(options.id==0){
    wx.request({
      url: 'https://api.tianapi.com/txapi/htmltext/index?key=07d06cd9cf942f096b3840d6004cd829'+'&url='+options.url,//页面文字提取api
      success: function(res) {
        console.log(res.data)
        var content = res.data.newslist[0].content
        var title = res.data.newslist[0].title
        var time = res.data.newslist[0].ctime
        that.setData({
          newcontent: content,
          newtitle:title,
          newtime:time
        })
      },
      fail: function(res) {
        console.log(res)
      }
    })
    }
    if(options.id==1){
      this.setData({
        newcontent:options.content
      })
    }

   
  },
})