// pages/master-oper/master-oper.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '',
    list:[],
    newpass:'',
    next_newpass:"",
    lab:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  newpass(e){
this.setData({
  newpass:e.detail.value
})
  },
  next_newpass(e) {
    this.setData({
      next_newpass: e.detail.value
    })
  },
  
  change(res){
    var that=this
    if(that.data.lab=="pass"){
      if (that.data.newpass == that.data.next_newpass) { 
      const db = wx.cloud.database();
      db.collection('Users').doc(that.data.id).update({
        data:{
          password:that.data.newpass
        }
        }).then(res => {
          wx.showToast({
            title: '密码修改成功',
            icon: 'none',
            duration: 1500
          })
          setTimeout(function () {
            wx.reLaunch({
              url: '../../pages/master/master',
            })
          }, 2000);
        })
      }else{
        wx.showToast({
          title: '两次输入不同',
          icon:'none',
          duration:2000
        })
      }
    }
    if (that.data.lab == "name") {
        const db = wx.cloud.database();
        db.collection('Users').doc( that.data.id
        ).update({
          data: {
            name: that.data.newpass
          }
          }).then(res => {
            wx.showToast({
              title: '用户名修改成功',
              icon: 'none',
              duration: 1500
            })
            setTimeout(function () {
              wx.reLaunch({
                url: '../../pages/master/master',
              })
            }, 2000);
          })
    }
    if (that.data.lab == "delete") {
      const db = wx.cloud.database();
      db.collection('Users').doc(that.data.id
      ).remove().then(res => {
        wx.showToast({
          title: '用户删除成功',
          icon: 'none',
          duration: 1500
        })
      })
    }

  },
  onLoad: function(options) {
    var that = this
    console.log(options)
    that.setData({
      id: options.id,
      lab:options.lab
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})