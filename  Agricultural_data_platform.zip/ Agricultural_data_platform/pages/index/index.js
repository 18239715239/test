wx - Page({

  /**
   * 页面的初始数据
   */
  data: {
    contentNewsList:[],
    reach:1,
    yangli:'',
    nongli:'',
    week:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    wx.request({//调用农历
      url: 'https://api.jisuapi.com/calendar/query?appkey=993123f768ea1000',
      success: function (res) {
        var data = res.data.result
        
        that.setData({
          nongli:data.huangli.nongli,
          yangli:data.lunaryear+'年'+data.month+'月'+data.day+'日',
          week:'周'+data.week
        })
      }
    })
    
    var reach = that.data.reach
    wx.request({
      url: 'https://way.jd.com/showapi/wbxh?page=1&maxResult=3&showapi_sign=bd0592992b4d4050bfc927fe7a4db9f3&appkey=1948902442a3e9836c9ef9d5b4b359b0',
      success: res => {
        console.log(res)

        that.setData({
          contentNewsList: res.data.result.showapi_res_body.contentlist,
          reach: reach + 1
        })
      }
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    wx.showLoading({
      title: '加载更多',
    });
    var that = this;
    var reach = that.data.reach
    wx.request({
      url: 'https://way.jd.com/showapi/wbxh?page='+reach+'&maxResult=3&showapi_sign=bd0592992b4d4050bfc927fe7a4db9f3&appkey=1948902442a3e9836c9ef9d5b4b359b0',
      success: res => {
        console.log(res)
        if (reach > 1) {
          var contentNewsListtemp = that.data.contentNewsList
          that.setData({
            contentNewsList: contentNewsListtemp.concat(res.data.result.showapi_res_body.contentlist),
            reach: reach + 1
          })
        } else {
          that.setData({
            contentNewsList: res.data.result.showapi_res_body.contentlist,
            reach: reach + 1
          })
        }
      },
      complete: function () {
        wx.hideLoading()
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})