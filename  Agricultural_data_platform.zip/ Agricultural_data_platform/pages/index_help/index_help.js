// pages/index_knows/index_knows.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    const db = wx.cloud.database();
    db.collection('help').get({
      success: function(res1) {
        wx.showLoading({
          title: '加载中',
          icon: 'none',
          duration: 1000
        })
        that.setData({
          list: res1.data,
        })
      },
      fail: function(res) {
        wx.showToast({
          title: '服务器异常',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function (res) {
        wx.hideLoading()
      },
    })

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    wx.showToast({
      title: '没有更多了',
      icon: 'none',
      duration: 1500
    })
  },
  loadmore: function(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/help-detail/help-detail?content=' + e.currentTarget.dataset.content,
      success: function(res) {
        wx.showLoading({
          title: '加载中',
          icon: 'none',
          duration: 1000
        })
      },
      fail: function(res) {
        wx.showToast({
          title: '服务器异常',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function(res) {
        wx.hideLoading()
      },
    })
  }
})