// pages/moredata/moredata.js
import wxCharts from '../../utils/wxcharts.js'
var windowW
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '',
    imageWidth: "",
    currentdata: "",
    todaydata: ['-1'],
    month: '',
    day: ""
  },
  onLoad: function(options) {

    this.setData({
      id: options.id
    })
  },
  month: function(res) {
    this.setData({
      month: res.detail.value
    })
  },
  day: function(res) {
    this.setData({
      day: res.detail.value
    })
  },
  lookmore: function() {
    //---------------------------------------------------------------------------------------
    if(this.data.id=='co2'){//查看co2的历史数据
      var that = this
      wx.showToast({
        title: '读取数据中',
        icon: 'loading',
        duration: 3000,
      })
      if (this.data.month == "" || this.data.day == "") {
        console.log(this.data.month)
        wx.showToast({
          title: '请输入正确的天数或月份',
          icon: 'none',
          duration: 3000,
        })
      } else {
        const db = wx.cloud.database();
        var name = app.globalData.nowphone + "-" + that.data.month + "-" + that.data.day;
        console.log(name)
        db.collection(name).get({
          success: res => {
            console.log(res)
            for (var i = 0; i < res.data.length; i++) {
              for (var j = 0; j < res.data.length - i - 1; j++) {
                if (res.data[j].time > res.data[j + 1].time) {
                  var temp = res.data[j];
                  res.data[j] = res.data[j + 1];
                  res.data[j + 1] = temp;
                }
              }
            }
            console.log(res.data)
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydata[i] = res.data[i].co2
              console.log(res.data[i].co2)
            }
            new wxCharts({
              canvasId: 'lineCanvas',
              type: 'line',
              categories: ['0h', '2h', '4h', '6h', '8h', '10h', '12h', '14h', '16h', '18h', '20h', '22h'],
              animation: true,
              background: '#f5f5f5',
              series: [{
                name: '二氧化碳24小时含量变化图示',
                data: this.data.todaydata,
              }],
              xAxis: {
                disableGrid: true,
              },
              yAxis: {
                title: '二氧化碳含量 (%)',
                format: function (val) {
                  return val.toFixed(2);
                },
                min: 0,
                max: 0.08,
              },
              width: this.data.imageWidth,
              height: 250,
              dataLabel: true,
              dataPointShape: true,
              extra: {
                lineStyle: 'curve'
              }
            })
          },
          fail: function (res) {
            wx.showToast({
              title: '暂无该天历史数据',
              icon: 'none',
              duration: 3000,
            })
          },
          complete: function (res) {
            wx.hideLoading()
            this.onshow()
          }
        })
        this.setData({
          imageWidth: wx.getSystemInfoSync().windowWidth
        });
      }
    } 
    //--------------------------------------------------------
    else if (this.data.id == 'KNF'){//查看土壤成分的历史数据
      var that = this
      wx.showToast({
        title: '读取数据中',
        icon: 'loading',
        duration: 3000,
      })
      if (this.data.month == "" || this.data.day == "") {
        console.log(this.data.month)
        wx.showToast({
          title: '请输入正确的天数或月份',
          icon: 'none',
          duration: 3000,
        })
      } else {
        const db = wx.cloud.database();
        var name = app.globalData.nowphone + "-" + that.data.month + "-" + that.data.day;
        db.collection(name).get({
          success: res => {
            console.log(res)
            for (var i = 0; i < res.data.length; i++) {
              for (var j = 0; j < res.data.length - i - 1; j++) {
                if (res.data[j].time > res.data[j + 1].time) {
                  var temp = res.data[j];
                  res.data[j] = res.data[j + 1];
                  res.data[j + 1] = temp;
                }
              }
            }
            // 获取K的数据
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydataK[i] = res.data[i].K
            }
            //获取N
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydataN[i] = res.data[i].N
            }
            //获取P
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydataP[i] = res.data[i].P
            }
            new wxCharts({
              canvasId: 'lineCanvas',
              type: 'line',
              categories: ['0h', '2h', '4h', '6h', '8h', '10h', '12h', '14h', '16h', '18h', '20h', '22h'],
              animation: true,
              background: '#f5f5f5',
              series: [{
                name: 'K含量24小时含量变化图示',
                data: this.data.todaydataK,
              },
              {
                name: 'N含量24小时含量变化图示',
                data: this.data.todaydataN,
              },
              {
                name: 'P含量24小时含量变化图示',
                data: this.data.todaydataP,
              }
              ],
              xAxis: {
                disableGrid: true,
              },
              yAxis: {
                title: '元素含量 (毫克/公斤)',
                format: function (val) {
                  return val.toFixed(2);
                },
                min: 0,
                max: 220,
              },
              width: this.data.imageWidth,
              height: 250,
              dataLabel: true,
              dataPointShape: true,
              extra: {
                lineStyle: 'curve'
              }
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '您未安装设备',
              icon: 'none',
              duration: 3000
            })
          }
        })
      }
    } //--------------------------------------------------------
    else if (this.data.id == 'lux') {//查看光照强度的历史数据
      var that = this
      wx.showToast({
        title: '读取数据中',
        icon: 'loading',
        duration: 3000,
      })
      if (this.data.month == "" || this.data.day == "") {
        console.log(this.data.month)
        wx.showToast({
          title: '请输入正确的天数或月份',
          icon: 'none',
          duration: 3000,
        })
      } else {
        const db = wx.cloud.database();
        var name = app.globalData.nowphone + "-" + that.data.month + "-" + that.data.day;
        console.log(name)
        db.collection(name).get({
          success: res => {
            console.log(res)
            for (var k = 0; k < res.data.length; k++) {
              if (res.data[k].time == h) {
                this.setData({
                  currentdata: res.data[k].lux
                })
              }
            }
            for (var i = 0; i < res.data.length; i++) {
              for (var j = 0; j < res.data.length - i - 1; j++) {
                if (res.data[j].time > res.data[j + 1].time) {
                  var temp = res.data[j];
                  res.data[j] = res.data[j + 1];
                  res.data[j + 1] = temp;
                }
              }
            }
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydata[i] = res.data[i].lux
              console.log(that.data.todaydata)
            }
            new wxCharts({
              canvasId: 'lineCanvas',
              type: 'line',
              categories: ['0h', '2h', '4h', '6h', '8h', '10h', '12h', '14h', '16h', '18h', '20h', '22h'],
              animation: true,
              background: '#f5f5f5',
              series: [{
                name: '光照强度24小时含量变化图示',
                data: this.data.todaydata,
              }],
              xAxis: {
                disableGrid: true,
              },
              yAxis: {
                title: '光照强度 (lx)',
                format: function (val) {
                  return val.toFixed(2);
                },
                min: 0,
                max: 0.08,
              },
              width: this.data.imageWidth,
              height: 250,
              dataLabel: true,
              dataPointShape: true,
              extra: {
                lineStyle: 'curve'
              }
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '您未安装设备',
              icon: 'none',
              duration: 3000
            })
          }

        })
        this.setData({
          imageWidth: wx.getSystemInfoSync().windowWidth
        });
      }
    } //--------------------------------------------------------
    else if (this.data.id == 'wenshi') {//查看温湿度的历史数据
      var that = this
      if (this.data.month == "" || this.data.day == "") {
        console.log(this.data.month)
        wx.showToast({
          title: '请输入正确的天数或月份',
          icon: 'none',
          duration: 3000,
        })
      } else {
        wx.showToast({
          title: '读取数据中',
          icon: 'loading',
          duration: 3000,
        })
        const db = wx.cloud.database();
        var name = app.globalData.nowphone+ "-" + that.data.month + "-" + that.data.day;
        console.log(name)
        db.collection(name).get({
          success: res => {
            console.log(res)
            for (var i = 0; i < res.data.length; i++) {
              for (var j = 0; j < res.data.length - i - 1; j++) {
                if (res.data[j].time > res.data[j + 1].time) {
                  var temp = res.data[j];
                  res.data[j] = res.data[j + 1];
                  res.data[j + 1] = temp;
                }
              }
            }
            //温度
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydatawen[i] = res.data[i].temp
            }
            //湿度
            for (var i = 0; i < res.data.length; i++) {
              that.data.todaydatashi[i] = res.data[i].humidity
            }
            new wxCharts({
              canvasId: 'lineCanvas',
              type: 'line',
              categories: ['0h', '2h', '4h', '6h', '8h', '10h', '12h', '14h', '16h', '18h', '20h', '22h'],
              animation: true,
              background: '#f5f5f5',
              series: [{
                name: '温度24小时含量变化图示',
                data: this.data.todaydatawen,
              },
              {
                name: '湿度24小时含量变化图示',
                data: this.data.todaydatashi,
              }],
              xAxis: {
                disableGrid: true,
              },
              yAxis: {
                title: '温度℃ 湿度 (%)',
                format: function (val) {
                  return val.toFixed(2);
                },
                min: 0,
                max: 0.08,
              },
              width: this.data.imageWidth,
              height: 250,
              dataLabel: true,
              dataPointShape: true,
              extra: {
                lineStyle: 'curve'
              }
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '您未安装设备',
              icon: 'none',
              duration: 3000
            })
          }
        })
        this.setData({
          imageWidth: wx.getSystemInfoSync().windowWidth
        });
      }
    }
  }

})