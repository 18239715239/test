var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    username: "kk",
    userphone: "123"
  },
  set(){
    wx.openSetting({
      success(){
      }
      ,fail(e){
        console.log(e)
      }
    })
  },
  onShow: function() {
    var that = this;
    console.log(app.globalData.nowphone)
    that.setData({
      username: app.globalData.nowname,
      userphone: app.globalData.nowphone
    })
    wx.getUserInfo({
      success: function(res) {
        console.log(res.userInfo);
        that.setData({
          userInfo: res.userInfo
        })
      }
    })
  
  },
  zhuce: function() {
    wx.navigateTo({
      url: '/pages/register/register',
    })
  },
  denglu: function() {
    wx.navigateTo({
      url: '/pages/login/user',
    })
  },
})