// 云函数入口文件
const cloud = require('wx-server-sdk')
//引入mysql操作模块
const mysql = require('mysql2/promise')
cloud.init()
// 云函数入口函数
exports.main = async (event, context) => {
  var table = "user" + event.phone
  var where ="where"+event.date
  try {
    const connection = await mysql.createConnection({
      host: "47.98.233.31",
      database: "user",
      user: "user",
      password: "Hq1028117@"
    })

    const [rows, fields] = await connection.execute('SELECT * FROM ' + table)
    return rows

  } catch (err) {
    console.log("链接错误", err)
    return err
  }
}