function move(obj,target,callback){
    clearInterval(obj.timer)
    obj.timer=setInterval(function(){
        var step=(target-obj.offsetLeft)/10
         step=step>0?Math.ceil(step):Math.floor(step)
        if(obj.offsetLeft==target){
            clearInterval(obj.timer)
            }
        obj.style.left=obj.offsetLeft+step+'px'},15)
        if(callback){
            callback()
         }
        }
var pic=document.querySelector('.pic')
var goodsr=document.querySelector('.goods-r')
var imgs=document.querySelectorAll('img')
var i=1;
var circle=document.querySelector('.aricle').querySelector('ul')
var lis=circle.children

// var timepic=setInterval(function(){
//     console.log(pic.offsetLeft);
//     if(i==pic.children.length){
//           move(pic,0)
//           i=1
//           }else{
//           move(pic,-1216*i)
//            i++
//              }
//     },1500)
// goodsr.addEventListener('mouseover',function(){
//     clearInterval(timepic)
// })
// goodsr.addEventListener('mouseout',function(){
//     i=1-pic.offsetLeft/1216
//      timepic=setInterval(function(){
//        if(i==pic.children.length){
//                move(pic,0)
//                i=1
//            }else{
//                move(pic,-1216*i)
//                i++
//            }
//        },1500)
// })
for(var j=0;j<imgs.length-1;j++){
    var li=document.createElement('li')
    circle.appendChild(li)
}
window.onload=function(){
    lis[0].style.backgroundColor='white'
}
goodsr.children[0].addEventListener('click',function(){
    if(i==pic.children.length){
        pic.style.left=0
        move(pic,-imgs[0].offsetWidth)
        i=2;
    }else{
        move(pic, -imgs[0].offsetWidth*i)
        i++;
    }
    for(var j=0;j<lis.length;j++){
        lis[j].style.backgroundColor=''
    }
    console.log(i);
    if(i==5){
        lis[0].style.backgroundColor='white' 
    }else{
        lis[i-1].style.backgroundColor='white'
    }
})
goodsr.children[1].addEventListener('click',function(){
    if(i==1){
        pic.style.left=-imgs[0].offsetWidth*4+'px'
        move(pic,-imgs[0].offsetWidth*3)
        i=4
    }else{ move(pic,-imgs[0].offsetWidth*(i-2))
        i--
    } 
    for(var j=0;j<lis.length;j++){
        lis[j].style.backgroundColor=''
    }
    if(i==5){
        lis[0].style.backgroundColor='white' 
    }else{
        lis[i-1].style.backgroundColor='white'
    }
})

console.log(lis);
// for(var i=0;i<lis.length;i++){
//     lis[i].addEventListener('click',function(){
//     move(pic,-imgs[0].offsetWidth*i)
//     // i=j+1
//     })
// }
lis[0].addEventListener('click',function(){
    move(pic,-imgs[0].offsetWidth*4)
    for(var i=0;i<lis.length;i++){
        lis[i].style.backgroundColor=''
    }
    lis[0].style.backgroundColor='white'
    i=5
})
lis[1].addEventListener('click',function(){
    move(pic,-imgs[0].offsetWidth*1)
    for(var i=0;i<lis.length;i++){
        lis[i].style.backgroundColor=''
    }
    lis[1].style.backgroundColor='white'
    i=2
})
lis[2].addEventListener('click',function(){
    move(pic,-imgs[0].offsetWidth*2)
    for(var i=0;i<lis.length;i++){
        lis[i].style.backgroundColor=''
    }
    lis[2].style.backgroundColor='white'
    i=3
})
lis[3].addEventListener('click',function(){
    move(pic,-imgs[0].offsetWidth*3)
    for(var i=0;i<lis.length;i++){
        lis[i].style.backgroundColor=''
    }
    lis[3].style.backgroundColor='white'
    i=4
})
var timers=setInterval(function(){
    goodsr.children[0].click();
},2000)
goodsr.addEventListener('mouseover',function(){
   clearInterval(timers)
})
goodsr.addEventListener('mouseout',function(){
    timers=setInterval(function(){
        goodsr.children[0].click();
    },2000)
 })
